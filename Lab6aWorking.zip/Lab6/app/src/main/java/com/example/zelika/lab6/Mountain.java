package com.example.zelika.lab6;

/**
 * Created by Zelika on 12/3/2017.
 */

public class Mountain {
    private String mountain;
    private  String mountainURL;

private void setMtInfo(Integer mtActivity){
    switch(mtActivity){
        case 0: //snowboarding
            mountain = "Crested Butte";
            mountainURL = "http://www.skicb.com/";
            break;
        case 1: //ski
            mountain = "Aspen: Snowmass";
            mountainURL = "https://www.aspensnowmass.com/";
            break;
        case 2: //day hiking
            mountain = "Grays Peak";
            mountainURL = "https://www.14ers.com/photos/peakmain.php?peak=Grays+Peak";
            break;
        case 3: //backpacking
            mountain = "Conundrum Springs";
            mountainURL = "https://www.alltrails.com/trail/us/colorado/conundrum-creek-trail-to-conundrum-hot-springs";
            break;
        case 4: //camping
            mountain = "TwinLakes";
            mountainURL = "http://www.visittwinlakes.com/";
            break;
        default:
            mountain = "none";
            mountainURL = "https://www.google.com/search?rlz=1C1CHZL_enUS752US752&ei=Ln4kWsT_Cce2jwO17bDACQ&q=mountain+activities+in+colorado&oq=mountain+act+in+colorado&gs_l=psy-ab.3.0.0i7i30k1j0i8i7i30k1l3.14016.18528.0.20494.12.12.0.0.0.0.232.1706.1j8j2.11.0....0...1c.1.64.psy-ab..2.10.1600...0j0i13k1.0.qcLr4ZunOp0";
    }
}

public void setMountain(Integer mtActivity){
    setMtInfo(mtActivity);
}
public void setMountainURL(Integer mtActivity){
    setMtInfo(mtActivity);
}
public String getMountain(){
    return mountain;
}

public String getMountainURL(){
    return mountainURL;
}
}
