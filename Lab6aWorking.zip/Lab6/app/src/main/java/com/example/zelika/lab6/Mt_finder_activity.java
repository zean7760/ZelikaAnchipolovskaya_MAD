package com.example.zelika.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;


public class Mt_finder_activity extends AppCompatActivity {

    private Mountain myMountain = new Mountain();

   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mt_finder_activity);

        //get button
        final Button button = (Button)findViewById(R.id.button);

        //create listner: used for more than just radio buttons and check list
        View.OnClickListener onclick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MtFinder(view);
                }
            };
        button.setOnClickListener(onclick);
    }



    public void MtFinder(View view){
        //get spinner
        Spinner activitySpinner = (Spinner)findViewById(R.id.spinner);

        //get spinner item array position
        Integer activity = activitySpinner.getSelectedItemPosition();

        myMountain.setMountain(activity);

        String suggestedMountain = myMountain.getMountain();

        String suggestedMountainURL = myMountain.getMountainURL();



        //create an intent
        Intent intent = new Intent(this, ReceiveMtActivity.class);

        //pass data
        intent.putExtra("mountainName", suggestedMountain);
        intent.putExtra("mountainNameURL", suggestedMountainURL);

        //start intent
        startActivity(intent);

    }
}
