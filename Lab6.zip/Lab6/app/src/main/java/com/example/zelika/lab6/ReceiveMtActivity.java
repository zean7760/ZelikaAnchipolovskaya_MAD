package com.example.zelika.lab6;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class ReceiveMtActivity extends AppCompatActivity {

    private String Mountain;
    private String MountainURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_mt);

        //get intent
        Intent intent = getIntent();
        Mountain = intent.getStringExtra("mountainName");
        MountainURL = intent.getStringExtra("mountainNameURL");
        Log.i("mt recieved", Mountain);
        Log.i("url recieved", MountainURL);

        //updata text view
        TextView messageView = (TextView)findViewById(R.id.mountianTextView);
        messageView.setText("You should check out " + Mountain);

        final ImageButton imageButton = (ImageButton)findViewById(R.id.imageButton);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebsite(view);
            }
        };
        //add listener button
        imageButton.setOnClickListener(onclick);
    }

    public void loadWebsite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(MountainURL));
        startActivity(intent);
    }
}
