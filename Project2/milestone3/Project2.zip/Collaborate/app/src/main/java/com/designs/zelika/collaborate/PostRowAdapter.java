package com.designs.zelika.collaborate;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Zelika on 5/2/2018.
 */


public class PostRowAdapter extends ArrayAdapter<Posts>{
    private PostsMainActivity activity;

//    private static class  ViewHolder{
//        TextView titleName;
//        TextView mesageName;
//    }
//    public static long getDateInMillis(String srcDate) {
//        SimpleDateFormat desiredFormat = new SimpleDateFormat(
//                "d MMMM yyyy, hh:mm aa");
//
//        long dateInMillis = 0;
//        try {
//            Date date = desiredFormat.parse(srcDate);
//            dateInMillis = date.getTime();
//            return dateInMillis;
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//
//        return 0;
//    }





    public PostRowAdapter(Context context, List<Posts> data) {
        super(context,0, data);
    }

    //@NonNull
    @Override
    public View getView(int position, View listItemView, @NonNull ViewGroup parent) {
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.row,parent,false);

        }


        TextView titleName = listItemView.findViewById(R.id.titleView);
        TextView messageName = listItemView.findViewById(R.id.messageView);
        //TextView timeSince = listItemView.findViewById(R.id.timeView);

        Posts posts = getItem(getCount()- position - 1); //get a reverse order list, newest at the top


//        CharSequence relativeDate =
//                DateUtils.getRelativeTimeSpanString(posts.hashCode(),
//                        System.currentTimeMillis(),
//                        DateUtils.MINUTE_IN_MILLIS,
//                        DateUtils.FORMAT_ABBREV_RELATIVE);

        if (posts != null) {
            titleName.setText(posts.getTitle());
            messageName.setText(posts.getMessage());
           // timeSince.setText(relativeDate);
        }
        return  listItemView;
    }


}
