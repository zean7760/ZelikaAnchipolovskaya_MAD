package com.designs.zelika.collaborate;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class PostsMainActivity extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance(); //database instance

    DatabaseReference ref = database.getReference(); //reference database

    DatabaseReference postref = database.getReference("posts");

    List posts = new ArrayList<>();

    ArrayAdapter<Posts> adapter;

   // private Calendar calendar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posts_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ListView postList = (ListView)findViewById(R.id.listView);
        postList.setDivider(getDrawable(R.drawable.divider));
        postList.setDividerHeight(25);
        final PostRowAdapter adapter = new PostRowAdapter(this,posts);
        postList.setAdapter(adapter);

        postList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                LinearLayout layout = new LinearLayout(PostsMainActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);

                final Posts post = (Posts) parent.getAdapter().getItem(i);
            }
        });

        ValueEventListener firebaseListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.clear();
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    String newId = snapshot.getKey();
                    Log.d("id", newId);

                    Posts postItem = snapshot.getValue(Posts.class);
                   // Long timestamp = (Long) snapshot.getValue();

                    Posts newPost = new Posts(newId, postItem.getTitle(),postItem.getMessage());
                    //Log.d("newPost", String.valueOf(newPost));

                    posts.add(newPost);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("oncreate", "Failed to read value.", databaseError.toException());
            }
        };
        postref.addValueEventListener(firebaseListener);

       FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout layout = new LinearLayout(PostsMainActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);

                final EditText nameEditText = new EditText(PostsMainActivity.this);
                nameEditText.setHint("Post Title");
                layout.addView(nameEditText);

                final EditText messageEditText = new EditText(PostsMainActivity.this);
                messageEditText.setHint("message");
                layout.addView(messageEditText);

                AlertDialog.Builder dialog = new AlertDialog.Builder(PostsMainActivity.this);
                dialog.setTitle("Add Post");
                dialog.setView(layout);
                dialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String postName = nameEditText.getText().toString();
                        String postMessage = messageEditText.getText().toString();
                        //Log.d("name title", postName);
                        if(postName.trim().length() > 0){
                            String key = postref.push().getKey();

                            Posts newPost = new Posts(key,postName, postMessage);


                            postref.child(key).child("title").setValue(newPost.getTitle());
                            postref.child(key).child("message").setValue(newPost.getMessage());

                            //postref.child(key).child("time").setValue(ServerValue.TIMESTAMP);
                        }
                    }
                });
                dialog.setNegativeButton("Cancel", null);
                dialog.show();
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menuLogout:

                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(this, SignInActivity.class));

                break;
        }

        return true;
    }
}
