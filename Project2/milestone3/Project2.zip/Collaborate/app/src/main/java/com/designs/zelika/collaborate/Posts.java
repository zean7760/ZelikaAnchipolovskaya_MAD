package com.designs.zelika.collaborate;

/**
 * Created by Zelika on 4/30/2018.
 */

public class Posts {

    private String id;
    private String title;
    private String message;

   // private Map time;

    private Posts(){

    }

    public Posts(String newid, String newTitle, String newMessage) {
        id = newid;
        title = newTitle;
        message = newMessage;
       // time = newtime;

    }


    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getMessage() {
        return message;
    }

    public String toString(){ //the string rep of the books name
        return this.title; //now name will show up in list when called
    }

//    public Map getTime() {
//        return time;
//    }

}
