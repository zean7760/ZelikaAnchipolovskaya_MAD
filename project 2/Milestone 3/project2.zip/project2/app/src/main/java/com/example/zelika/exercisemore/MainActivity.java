package com.example.zelika.exercisemore;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    ToggleButton easy_toggle;
    ToggleButton med_toggle;
    ToggleButton hard_toggle;

    ToggleButton cardio_toggle;
    ToggleButton strength_toggle;

    Button send_button;

    String workout;
    String challenge;

    String formatedDate;

    Format formatedTime;
    private TimePicker timepicker;
    private Calendar calendar;
    private String format = "";
    String time;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        send_button = (Button) findViewById(R.id.button);

        DatePicker datePicker = (DatePicker) findViewById(R.id.datePicker2);

        timepicker = (TimePicker) findViewById(R.id.timePicker);

        int hour = timepicker.getCurrentHour();
        int min = timepicker.getCurrentMinute();

        calendar = Calendar.getInstance();


        formatedTime = new SimpleDateFormat("h:mm a");
        time = formatedTime.format(calendar.getTime());


        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth();
        int year = datePicker.getYear() - 1900;

        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        formatedDate = sdf.format(new Date(year, month, day));


        easy_toggle = (ToggleButton) findViewById(R.id.easy_button);
//        easy_toggle.setChecked(true);
        boolean easy = easy_toggle.isChecked();


        med_toggle = (ToggleButton) findViewById(R.id.med_button);
        boolean med = med_toggle.isChecked();

        hard_toggle = (ToggleButton) findViewById(R.id.hard_button);
        boolean hard = hard_toggle.isChecked();

        cardio_toggle = (ToggleButton) findViewById(R.id.cardio_button);
        boolean cardio = cardio_toggle.isChecked();

        strength_toggle = (ToggleButton) findViewById(R.id.strength_button);
//        strength_toggle.setChecked(true);
        boolean strength = strength_toggle.isChecked();

        easy_toggle.setOnCheckedChangeListener(changeChecker);
        med_toggle.setOnCheckedChangeListener(changeChecker);
        hard_toggle.setOnCheckedChangeListener(changeChecker);

        cardio_toggle.setOnCheckedChangeListener(changeChecker);
        strength_toggle.setOnCheckedChangeListener(changeChecker);

        //get button
//        final Button button = (Button)findViewById(R.id.button);

        //create listner: used for more than just radio buttons and check list
        View.OnClickListener onclick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intentHistory(view);
            }
        };
        send_button.setOnClickListener(onclick);
    }

//    public void showTime(int hour, int min) {
//        if (hour == 0) {
//            hour += 12;
//            format = "AM";
//        } else if (hour == 12) {
//            format = "PM";
//        } else if (hour > 12) {
//            hour -= 12;
//            format = "PM";
//        } else {
//            format = "AM";
//        }
//
//    }


    CompoundButton.OnCheckedChangeListener changeChecker = new CompoundButton.OnCheckedChangeListener() {


        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                if (buttonView == easy_toggle) {
                    med_toggle.setChecked(false);
                    hard_toggle.setChecked(false);
                    challenge = "Difficulty: easy";
                }
                if (buttonView == med_toggle) {
                    easy_toggle.setChecked(false);
                    hard_toggle.setChecked(false);
                    challenge = "Difficulty:  medium";
                }
                if (buttonView == hard_toggle) {
                    med_toggle.setChecked(false);
                    easy_toggle.setChecked(false);
                    challenge = "Difficulty: hard";
                }
                if (buttonView == cardio_toggle) {
                    strength_toggle.setChecked(false);
                    workout = "Type: cardio";
                }
                if (buttonView == strength_toggle) {
                    cardio_toggle.setChecked(false);
                    workout = "Type: strength";
                }

            }
        }
    };


    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
    }

    public void intentHistory(View view) {
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
//        showTime(hour, min);

        if (cardio_toggle.isChecked() || strength_toggle.isChecked() && easy_toggle.isChecked() || med_toggle.isChecked() || hard_toggle.isChecked()){

            send_button.setOnClickListener(new View.OnClickListener() {

                public void onClick(View view) {


                    Intent intent = new Intent(view.getContext(), historyPage.class);

                    intent.putExtra("challenge", challenge);
                    intent.putExtra("workout", workout);
                    intent.putExtra("date", formatedDate);
                    intent.putExtra("time", time);
//                intent.putExtra("format", format);

                    startActivity(intent);

                }
            });
        }else{
            Context context=getApplicationContext();
            CharSequence text="Please select a difficulty and/or activity";
            int duration= Toast.LENGTH_LONG;

            Toast toast=Toast.makeText(context,text,duration);
            toast.show();
        }
    }
}

