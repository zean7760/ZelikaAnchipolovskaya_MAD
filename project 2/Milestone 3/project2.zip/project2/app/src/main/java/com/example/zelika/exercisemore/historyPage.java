package com.example.zelika.exercisemore;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class historyPage extends AppCompatActivity {

    TextView text;
    private String challenge;
    private  String workout;
    private  String formatedDate;
    private String time;
//    private String format;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_page);

        text = (TextView) findViewById(R.id.textView);

        Intent intent = getIntent();

        formatedDate = intent.getStringExtra("date");
        challenge = intent.getStringExtra("challenge");
        workout = intent.getStringExtra("workout");
        time = intent.getStringExtra("time");
//        format = intent.getStringExtra("format");

        text.setText(time + "\n" + formatedDate + "\n" + challenge + "\n" + workout);


    }
}
