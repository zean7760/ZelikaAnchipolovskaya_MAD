package com.designs.zelika.lab9;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class BookMainActivity extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance(); //database instance

    DatabaseReference ref = database.getReference(); //reference database

    DatabaseReference bookref = database.getReference("my books"); //node refenence

    List books = new ArrayList<>(); //array list of books

    ArrayAdapter<BookItem>listAdapter; //array adapter for info from java class

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ListView bookList = (ListView)findViewById(R.id.listView);
        listAdapter = new ArrayAdapter<BookItem>(this,android.R.layout.simple_list_item_1,books);
        bookList.setAdapter(listAdapter);

        registerForContextMenu(bookList);

        //read from database
        ValueEventListener firebaseListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //called with initial value then again when data in this location is updated

                //empty the arraylist
                books.clear();
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    //gets the item id
                    String newId = snapshot.getKey();
                    //Log.d("newif snapshot", snapshot.getKey());

                    BookItem bookItem = snapshot.getValue(BookItem.class); //get book from snapshot

                    BookItem newBook = new BookItem(newId,bookItem.getName(),bookItem.getUrl()); //creates new Bookitem object

                    books.add(newBook);//adds new book to array

                }

                listAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                //failed to read value
                Log.w("oncreate","Failed to read value", databaseError.toException());
            }
        };

        bookref.addValueEventListener(firebaseListener); //add listener to database book node reference

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout layout = new LinearLayout(BookMainActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL); //creates vertical linear layout to hold edit text

                final EditText nameEditText = new EditText(BookMainActivity.this);
                nameEditText.setHint("Book title"); //creates edit text and add to layout

                layout.addView(nameEditText);
                final EditText urlEditText = new EditText(BookMainActivity.this);
                urlEditText.setHint("URL");
                layout.addView(urlEditText);

                //create alert dialog box
                AlertDialog.Builder dialog = new AlertDialog.Builder(BookMainActivity.this);
                dialog.setTitle("Add Book");
                dialog.setView(layout);
                dialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //get entered data
                        String bookName = nameEditText.getText().toString();
                        String bookURL = urlEditText.getText().toString();
                        if(bookName.trim().length() > 0){
                            //get new id from firebase
                            String key = bookref.push().getKey();
                            //create new book item
                            BookItem newBook = new BookItem(key, bookName, bookURL);

                            //add to firebase
                            bookref.child(key).child("name").setValue(newBook.getName());
                            bookref.child(key).child("url").setValue(newBook.getUrl());
                        }
                    }
                });
                dialog.setNegativeButton("Cancel", null);
                dialog.show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_book_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
//deleteing item with a long press
    @Override
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, view, menuInfo);

        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo)menuInfo;

        String bookname = ((TextView) adapterContextMenuInfo.targetView).getText().toString();

        menu.setHeaderTitle("Delete" + bookname);

        menu.add(1,1,1, "yes");
        menu.add(2,2,2,"no");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {

        //get the id of the item
        int itemId = item.getItemId();
        if (itemId == 1){ //ifyes is pressed
            //get position of the menu item
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();

            //get book that was pressed
            BookItem selectedBook = (BookItem)books.get(info.position);

            //get book id
            String bookid = selectedBook.getId();

            //delete from firebase
            bookref.child(bookid).removeValue();
        }
        return true;
    }
}
