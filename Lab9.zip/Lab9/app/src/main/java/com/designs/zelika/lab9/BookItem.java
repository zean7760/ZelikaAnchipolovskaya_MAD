package com.designs.zelika.lab9;

/**
 * Created by Zelika on 4/30/2018.
 */

public class BookItem {
    private String id;
    private String name;
    private String url;

    public BookItem(){

    }

    public BookItem(String newid, String newName, String newURL){
        id = newid;
        name = newName;
        url = newURL;
    }

    public String getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    public String getUrl(){
        return url;
    }

    public String toString(){ //the string rep of the books name
        return this.name; //now name will show up in list when called
    }
}
