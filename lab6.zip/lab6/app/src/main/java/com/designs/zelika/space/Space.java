package com.designs.zelika.space;

/**
 * Created by Zelika on 3/31/2018.
 */

public class Space {
    private String name;
    private int imageResourceID;

    private Space(String newname, int newID){
        this.name = newname;
        this.imageResourceID = newID;
    }

    public static final Space[]Planets = {
            new Space("Mars", R.drawable.mars),
            new Space("Saturn", R.drawable.saturn),
            new Space("Neptune",R.drawable.neptune)

    };

    public static final Space[]Stars = {
            new Space("SuperNova", R.drawable.supernova),
            new Space("Pulsar", R.drawable.pulsar_star),
            new Space("BlackHole",R.drawable.blackhole)

    };

    public static final Space[]Galaxies = {
            new Space("Spiral", R.drawable.spiral),
            new Space("Irregular", R.drawable.irregular),
            new Space("Eliptical", R.drawable.eliptical)
    };

    public String getName(){
        return name;
    }

    public int getImageResourceID(){
        return imageResourceID;
    }

    public String toString(){
        return this.name;
    }


}
