package com.designs.zelika.space;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SpaceCategoryActivity extends ListActivity {

    private String spaceobject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("intent","spaceobject");

        Intent i = getIntent();
        spaceobject = i.getStringExtra("spaceobject");
        Log.d("intent","spaceobject");

        ListView listobject = getListView();

        ArrayAdapter<Space>listAdapter;

        switch(spaceobject){
            case"Planets":
                listAdapter = new ArrayAdapter<Space>(this,android.R.layout.simple_list_item_1, Space.Planets);
                break;

            case"Stars":
                listAdapter = new ArrayAdapter<Space>(this,android.R.layout.simple_list_item_1, Space.Stars);
                break;
            case"Galaxies":
                listAdapter = new ArrayAdapter<Space>(this, android.R.layout.simple_list_item_1,Space.Galaxies);
                break;


            default: listAdapter = new ArrayAdapter<Space>(this, android.R.layout.simple_list_item_1, Space.Planets);


        }
        listobject.setAdapter(listAdapter);
    }
    @Override
    public void onListItemClick(ListView listView, View view, int position, long id){
        Intent intent = new Intent(SpaceCategoryActivity.this, SpaceActivity.class);
        intent.putExtra("spaceid", (int) id);
        intent.putExtra("spacetype", (String) spaceobject);
        startActivity(intent);
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.create_order:
                Intent intent = new Intent(this, OrderActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
