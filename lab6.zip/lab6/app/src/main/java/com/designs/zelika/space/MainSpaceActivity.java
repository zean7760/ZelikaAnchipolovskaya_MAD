package com.designs.zelika.space;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainSpaceActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_space);

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
                String spaceobject = (String) listView.getItemAtPosition(position);
                //Log.d("intent","main to spaceCat");

                Intent intent = new Intent(MainSpaceActivity.this,SpaceCategoryActivity.class);
                //Log.d("after INtent","error");

                intent.putExtra("spaceobject", spaceobject);

                startActivity(intent);
                Log.d("start","activity started");
            }
        };
        ListView listview = (ListView)findViewById(R.id.listView);

        listview.setOnItemClickListener(itemClickListener);
    }
}
