package com.designs.zelika.space;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;


public class MainSpaceActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_space);

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
                String spaceobject = (String) listView.getItemAtPosition(position);
                //Log.d("intent","main::spaceobject");


                Intent intent = new Intent(MainSpaceActivity.this, SpaceCategoryActivity.class);
                //Log.d("after INtent","error");

                intent.putExtra("spaceobject", spaceobject);

                startActivity(intent);

            }
        };
            ListView listview = (ListView)findViewById(R.id.listView);
        //listview.setBackgroundColor(android.R.color.black);

        listview.setOnItemClickListener(itemClickListener);
    }


    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.create_order:
                Intent intent = new Intent(this, OrderActivity.class);
                startActivity(intent);
                return  true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
