package com.designs.zelika.space;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class SpaceActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_space);

        int spacenum = (Integer)getIntent().getExtras().get("spaceid");
        String spacetype = (String)getIntent().getExtras().get("spacetype");
        Space space;

        switch (spacetype){
            case "Planets":
                space = Space.Planets[spacenum];
                break;

            case "Stars":
                space = Space.Stars[spacenum];
                break;
            case "Galaxies":
                space = Space.Galaxies[spacenum];
                break;

            default:
                space = Space.Planets[spacenum];
        }


        ImageView spaceImage = (ImageView)findViewById(R.id.spaceImageView);
        spaceImage.setImageResource(space.getImageResourceID());

        TextView spaceName = (TextView)findViewById(R.id.space_name);
        spaceName.setText(space.getName());
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.create_order:
                Intent intent = new Intent(this, OrderActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
