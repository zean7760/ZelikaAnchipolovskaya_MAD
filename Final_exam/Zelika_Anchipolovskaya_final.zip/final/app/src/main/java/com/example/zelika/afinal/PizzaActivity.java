package com.example.zelika.afinal;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

public class PizzaActivity extends AppCompatActivity {

    String sizePizza;
    String crustPizza;
    String saucePizza;
    String toppingPizza;

    CheckBox cheeseCheckBox;
    CheckBox veggieCheckBox;
    CheckBox meatCheckBox;
    CheckBox supremeCheckBox;

    EditText pizzaname;
    String nameValue;
    String suggestion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza);


    }



    public void findPizza(View view) {
        //text view
        TextView pizzaText = (TextView) findViewById(R.id.textView);
        TextView suggestText = (TextView) findViewById(R.id.suggested);
        //edit text
//        EditText name = (EditText)findViewById(R.id.editText);
//        String nameValue = name.getText().toString();

        //toggle
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean sauce = toggle.isChecked();

        //spinner
        Spinner Size = (Spinner) findViewById(R.id.spinner);
        String SizeType = String.valueOf(Size.getSelectedItem());

        //radio
        RadioGroup crustType = (RadioGroup) findViewById(R.id.radioGroup);
        int crust = crustType.getCheckedRadioButtonId();

        //check box
        cheeseCheckBox = (CheckBox) findViewById(R.id.checkBox1);
        Boolean cheese = cheeseCheckBox.isChecked();

        veggieCheckBox = (CheckBox) findViewById(R.id.checkBox2);
        Boolean veggie = veggieCheckBox.isChecked();

        meatCheckBox = (CheckBox) findViewById(R.id.checkBox3);
        Boolean meat = meatCheckBox.isChecked();

        supremeCheckBox = (CheckBox) findViewById(R.id.checkBox4);
        Boolean supreme = supremeCheckBox.isChecked();

        pizzaname = (EditText)findViewById(R.id.pizzaName);
        nameValue = pizzaname.getText().toString();


        if (sauce) { //white
            saucePizza = "white Sause";
            if (crust == (R.id.radioButton1)) { //thin
                crustPizza = "thin crust";
                suggestion = "go to Pizzeria Locale";
                switch (SizeType) {
                    case "Small":
                        sizePizza = "small";
                        break;
                    case "Medium":
                        sizePizza = "medium";
                        break;
                    case "Large":
                        sizePizza = "large";

                }
            } else { //thick
                crustPizza = "thick crust";
                suggestion = " go to Old Chicago";

                switch (SizeType) {
                    case "Small":
                        sizePizza = "small";
                        break;
                    case "Medium":
                        sizePizza = "medium";
                        break;
                    case "Large":
                        sizePizza = "large";

                }

            }
        } else { //red
            saucePizza = "red sauce";
            if (crust == (R.id.radioButton1)) {
                crustPizza = "thin crust";
                switch (SizeType) {
                    case "Small":
                        sizePizza = "small";
                        break;
                    case "Medium":
                        sizePizza = "medium";
                        break;
                    case "Large":
                        sizePizza = "large";
                }
            }

        }



                    if (cheese == true) {
                        toppingPizza = "Cheese";
                    }
                    if (veggie == true) {
                        toppingPizza = "Veggie";
                    }
                    if (meat == true) {
                        toppingPizza = "Meat Lover's";
                        suggestion= "Order Papa John's";
                    }
                    if (supreme == true) {
                        toppingPizza = "Supreme";
                    }


        TextView pizza = (TextView) findViewById(R.id.textView);
        TextView store = (TextView) findViewById(R.id.suggested);
        pizzaText.setText(nameValue + " " + sizePizza + " " + saucePizza + " " + crustPizza + " " + toppingPizza + " " + "pizza");
        suggestText.setText("You should probably " + suggestion);
    }

}