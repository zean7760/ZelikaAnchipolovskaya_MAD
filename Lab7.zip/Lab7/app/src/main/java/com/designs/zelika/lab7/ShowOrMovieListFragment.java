package com.designs.zelika.lab7;


import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;



/**
 * A simple {@link Fragment} subclass.
 */
public class ShowOrMovieListFragment extends Fragment implements AdapterView.OnItemClickListener {


    public ShowOrMovieListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_show_or_movie_list, container, false);

    }

    @Override
    public void onStart(){
        super.onStart();
        View view = getView();
        if(view != null){
            //load data into fragment
            //get list view
            ListView listShowormovie = (ListView)view.findViewById(R.id.listView);

            Log.d("get the list view", String.valueOf(listShowormovie));



            //define an array adapter
            ArrayAdapter<Netflix> listAdapter = new ArrayAdapter<Netflix>(getActivity(), android.R.layout.simple_list_item_1, Netflix.options);
            Log.d("listA", String.valueOf(listAdapter));
            //set the array adapter on the list view
            listShowormovie.setAdapter(listAdapter);

            listShowormovie.setOnItemClickListener(this);

        }
    }

    interface MovieOrShowListListener{
        void itemClicked(long id);
    }

    //create listener
    private MovieOrShowListListener listener;


    @Override public void onAttach(Context context){
        super.onAttach(context);

        //attaches the context to the listener
        listener=(MovieOrShowListListener)context;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if(listener != null){
            //tell the lister an item was clicked
            listener.itemClicked(id);
        }
    }



}
