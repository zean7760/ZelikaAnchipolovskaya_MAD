package com.designs.zelika.lab7;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by Zelika on 4/10/2018.
 */

public class Netflix {
    private String showormovie;
    private ArrayList<String> watchlist = new ArrayList<>();

    //constructor
    private Netflix(String movorsho, ArrayList<String>options){
        this.showormovie= movorsho;
        this.watchlist = new ArrayList<String>(options);
    }

    public static final Netflix[] options={
      new Netflix("Show", new ArrayList<String>(Arrays.asList("Stranger Things", "Black Mirror", "The Walking Dead", "Breaking Bad", "Greys Anatomy","House of Cards", "Forensic Files"))),
      new Netflix("Movie", new ArrayList<String>(Arrays.asList("Jumanji", "300", "Walk Hard: The Dewey Cox Story", "The Conjuring ","Law abiding Citizen", "Insidious")))
    };

    public String getShowormovie(){
        return showormovie;
    }

    public ArrayList<String>getWatchlist(){
        return watchlist;
    }

    public String toString(){
        return this.showormovie;
    }


}
