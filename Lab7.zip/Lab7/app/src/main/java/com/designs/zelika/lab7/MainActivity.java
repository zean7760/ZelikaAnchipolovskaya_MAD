package com.designs.zelika.lab7;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.os.Bundle;

public class MainActivity extends Activity implements ShowOrMovieListFragment.MovieOrShowListListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Override public void itemClicked(long id){
        //create new fragment instance
        MovieDetailFragment frag = new MovieDetailFragment();
        //set the id of the show or movie selected
        frag.setShowOrMovie(id);
        //create new frag transaction
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        //replace the frag in the frag container
        ft.replace(R.id.fragment_container,frag);
        //add  fragmnet to the back stack
        ft.addToBackStack(null);
        //set the transition
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        //commit the trasaction
        ft.commit();

    }

    @Override public void onBackPressed(){
        if(getFragmentManager().getBackStackEntryCount()>0){
            getFragmentManager().popBackStack();
        }else{
            super.onBackPressed();
        }
    }
}
