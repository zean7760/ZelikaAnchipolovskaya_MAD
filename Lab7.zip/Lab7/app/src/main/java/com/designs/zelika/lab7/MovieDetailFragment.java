package com.designs.zelika.lab7;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class MovieDetailFragment extends Fragment {


    public MovieDetailFragment() {
        // Required empty public constructor
    }

    private ArrayAdapter<String>adapter;

    private long showormovieId;

    public void setShowOrMovie(long id){
        this.showormovieId=id;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if(savedInstanceState != null){
            showormovieId=savedInstanceState.getLong("showormovieId");
        }
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_movie_detail, container, false);
    }

    @Override public void onStart() {
        super.onStart();

        View view = getView();
        ListView listMovies = (ListView)view.findViewById(R.id.movielistView);

        ArrayList<String>movielist = new ArrayList<String>();
        movielist=Netflix.options[(int)showormovieId].getWatchlist();

        adapter=new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,movielist);

        listMovies.setAdapter(adapter);
    }

    @Override public void onSaveInstanceState(Bundle saveInstanceState){
        saveInstanceState.putLong("showormovieId", showormovieId);
    }




}
