package com.example.zelika.lab5;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void findSchool(View view){
        //text view
        TextView schoolText = (TextView) findViewById(R.id.schoolTextView);
        //edit text
        EditText name = (EditText)findViewById(R.id.editText);
        String nameValue = name.getText().toString();

        //toggle
        ToggleButton toggle = (ToggleButton)findViewById(R.id.toggleButton);
        boolean location = toggle.isChecked();

        //spinner
        Spinner Focus = (Spinner)findViewById(R.id.spinner);
        String focusType = String.valueOf(Focus.getSelectedItem());

        //radio
        RadioGroup cost=(RadioGroup)findViewById(R.id.radioGroup);
        int cost_id=cost.getCheckedRadioButtonId();

        //check box
        CheckBox smallCheckBox=(CheckBox)findViewById(R.id.checkBox);
        Boolean small=smallCheckBox.isChecked();

        CheckBox mediumgCheckBox=(CheckBox)findViewById(R.id.checkBox2);
        Boolean medium=mediumgCheckBox.isChecked();

        CheckBox largeCheckBox=(CheckBox)findViewById(R.id.checkBox3);
        Boolean large=largeCheckBox.isChecked();


        //image view
        //ImageView ghost = (ImageView)findViewById(R.id.imageView);
        //ghost.setImageResource(R.drawable.my_rides);

        String perfectSchool;

        if(cost_id == -1){
            //toast
            Context context=getApplicationContext();
            CharSequence text="Please select a cost level";
            int duration= Toast.LENGTH_SHORT;

            Toast toast=Toast.makeText(context,text,duration);
            toast.show();
        }else {
            if (location) { //in state
                if (cost_id == R.id.radioButton1) {
                    perfectSchool = "Community College";
                } else {
                    switch (focusType) {
                        case "Engineering":
                            perfectSchool = "CU Boulder";
                            break;
                        case "Arts and Science":
                            perfectSchool = "University of Northern Colorado";
                            break;
                        case "Quick Program":
                            perfectSchool = "Trade school";
                            break;
                        default:
                            perfectSchool = "CU Boulder";
                    }
                }
            } else { //out of state
                if (cost_id == R.id.radioButton3) {
                    if (large) {
                        perfectSchool = "University of Central Florida";
                    } else {
                        perfectSchool = "Johns Hopkins University";
                    }
                } else {
                    switch (focusType) {
                        case "Engineering":
                            perfectSchool = "California State University-Los Angeles";
                            break;
                        case "Arts":
                            perfectSchool = "University of Southern Mississippi";
                            break;
                        case "Quick Program":
                            perfectSchool = "Trade School";
                            break;
                        default:
                            perfectSchool = "UCLA";
                    }
                }
            }
            TextView schoolSelection = (TextView) findViewById(R.id.schoolTextView);
            schoolText.setText(nameValue + ", you should attend " + perfectSchool + "!");

        }
    }
}
