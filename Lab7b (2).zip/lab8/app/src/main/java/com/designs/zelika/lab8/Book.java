package com.designs.zelika.lab8;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

/**
 * Created by Zelika on 4/22/2018.
 */

public class Book extends RealmObject{

    @Required
    @PrimaryKey
    private String id;
    private String book_name;
    private String auther_name;
    private boolean read;

    public String getId(){
        return id;
    }

    public void setId(String id){
        this.id = id;
    }

    public String getBook_name(){
        return book_name;
    }

    public void setBook_name(String book){
        this.book_name = book;
    }

    public String getAuther_name(){
        return auther_name;
    }

    public void setAuther_name(String auther){
        this.auther_name = auther;
    }

    public boolean hasRead(){
        return read;
    }

    public void setRead(Boolean done){
        this.read = done;
    }

}
