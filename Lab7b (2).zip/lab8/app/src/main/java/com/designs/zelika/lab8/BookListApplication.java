package com.designs.zelika.lab8;

import android.app.Application;

import io.realm.Realm;
import io.realm.RealmConfiguration;

/**
 * Created by Zelika on 4/22/2018.
 */

public class BookListApplication extends Application {

    @Override public void onCreate(){
        super.onCreate();

        Realm.init(this);

        RealmConfiguration realmConfig = new RealmConfiguration.Builder().build();

        Realm.setDefaultConfiguration(realmConfig);

    }
}

