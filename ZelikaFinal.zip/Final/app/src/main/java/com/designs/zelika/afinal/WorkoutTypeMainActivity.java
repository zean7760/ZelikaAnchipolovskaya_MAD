package com.designs.zelika.afinal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class WorkoutTypeMainActivity extends Activity {
   // private Realm realm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_type_main);

       // realm = Realm.getDefaultInstance();
        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
                String workoutobject = (String) listView.getItemAtPosition(position);

                Intent intent = new Intent(WorkoutTypeMainActivity.this, WorkoutCategoryActivity.class);

                intent.putExtra("workoutobject",workoutobject );

                startActivity(intent);
            }
        };
        ListView listView = (ListView)findViewById(R.id.workoutTypeList);





    }
}
