package com.designs.zelika.afinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Zelika on 5/6/2018.
 */

public class WorkoutAdapter extends ArrayAdapter<Workout>  {

    private WorkoutTypeMainActivity activity;

    private static class  ViewHolder {
        TextView workoutName;
    }
    public WorkoutAdapter(Context context, List<Workout> data) {
        super(context,0,data);
        this.activity = activity;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       ViewHolder viewHolder;

       if(convertView == null) {
           convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, parent, false);
            viewHolder = new ViewHolder();

       }
        TextView workout = convertView.findViewById(R.id.WorkoutTypeTextView);
        ListView types = convertView.findViewById(R.id.workoutTypeList);

       Workout workouts = getItem(getCount());
       if (workouts != null){
           workout.setText(workouts.getName());

       }


        return convertView;
    }


}
