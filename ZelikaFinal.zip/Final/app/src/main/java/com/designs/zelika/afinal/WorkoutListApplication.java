package com.designs.zelika.afinal;

import android.app.Application;

import io.realm.Realm;
import io.realm.RealmConfiguration;

/**
 * Created by Zelika on 5/6/2018.
 */

public class WorkoutListApplication extends Application {
    @Override public void onCreate(){
        super.onCreate();

        Realm.init(this);

        RealmConfiguration realmConfig = new RealmConfiguration.Builder().build();

        Realm.setDefaultConfiguration(realmConfig);

    }
}
