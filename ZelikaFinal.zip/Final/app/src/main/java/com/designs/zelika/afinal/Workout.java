package com.designs.zelika.afinal;

import io.realm.RealmObject;

/**
 * Created by Zelika on 5/6/2018.
 */

public class Workout extends RealmObject {
    private String name;
    private String id;

    private Workout(String newname, String newid){
        this.name = newname;
        this.id = newid;
    }
    public Workout(){

    }

    public static final Workout[]Cardio = {
            //new Workout("running",name)


    };

    public static final Workout[]Strength ={
           // new Workout("yoga)",name)

    };

    public static final Workout[]Flexibility = {
            //new Workout("stretching", name)
    };

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }

    public String toString(){
        return this.name;
    }
}


