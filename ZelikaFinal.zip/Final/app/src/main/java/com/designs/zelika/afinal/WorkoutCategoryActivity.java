package com.designs.zelika.afinal;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class WorkoutCategoryActivity extends ListActivity {
    private String workoutobject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_category);

        Intent i = getIntent();
        workoutobject = i.getStringExtra("workoutobject");

        ListView listobject = getListView();

        ArrayAdapter<Workout> listAdapeter;

        switch (workoutobject) {
            case "Strength":
                listAdapeter = new ArrayAdapter<Workout>(this, android.R.layout.simple_list_item_1, Workout.Strength);
                break;

            case "Cardio":
                listAdapeter = new ArrayAdapter<Workout>(this, android.R.layout.simple_list_item_1, Workout.Cardio);
                break;

            case "Flexibility":
                listAdapeter = new ArrayAdapter<Workout>(this, android.R.layout.simple_list_item_1, Workout.Flexibility);
                break;

            default:
                listAdapeter = new ArrayAdapter<Workout>(this, android.R.layout.simple_list_item_1, Workout.Cardio);

        }
        listobject.setAdapter(listAdapeter);
    }

//    @Override
//    public void onListItemClick(ListView listView, View view, int position, long id){
//        Intent intent = new Intent(WorkoutCategoryActivity.this, WorkoutActivity.class);
//        intent.putExtra("workoutid", (int) id);
//        intent.putExtra("workouttype", (String) workoutobject);
//        startActivity(intent);
//    }



}


